pkill python3;echo "[!]Haunter process stopped"
