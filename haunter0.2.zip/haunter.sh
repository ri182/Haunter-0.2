nohup python3 haunter.py&
